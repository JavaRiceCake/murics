<?php
include_once('partials/header.php');
include('model/dbcon.php');
include('controller/lyricsController.php');
if(isset($_GET['page_no']) && $_GET['page_no'] !== ""){
  $page_no = $_GET['page_no'];
}else{
  $page_no = 1;
}


?>

<div id="mainContainer" class="flex w-full flex-nowrap flex-col">
    <?php
   $limiter = 4;
   $sides = round(($limiter/4), 0, PHP_ROUND_HALF_DOWN);
    $t_r_p = 10 ; // total dispaly record
    $offset =($page_no - 1)* $t_r_p ; // limit query
    $prev = $page_no - 1;
    $next = $page_no + 1;
    $page = new Page();
    $prvNxt = new Page();
    $pages=$prvNxt->prvNxt($t_r_p);
    $results = $page->page($offset,$t_r_p);
    foreach ($results as $result) {
        ?>
    <div id="contentContainer" class="w-full p-3">
        <div>
        <iframe width="100%" height="220" src="<?php echo $result['url']?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <div>
        <p class="font-semibold mb-2 text-white" ><?php echo $result['title']?></p>
            <div class="flex justify-between border-solid border-b-2 border-cyan-200 pb-1">
                <div class="flex items-center">
                <a href="view/lyrics.php?id=<?php echo $result['id']?>" class="bg-cyan-500 rounded-full text-black font-semibold py-1.5 px-10 tracking-wider hover:bg-cyan-400 mr-1.5" >Lyrics</a>

                <input type="hidden" name="favorite" id="hfavorite" value="<?php echo $result['favorite']?>">
                <?php
                if($result['favorite']=='Like'){
                ?>
                 <button onclick="dislike(this)" id="<?php echo $result['id']?>"><i class="material-icons text-3xl text-red-500" id="favorite<?php echo $result['id']?>">favorite</i></button>
                <?php
                }else{
                ?>
                     <button onclick="like(this)" id="<?php echo $result['id']?>"><i class="material-icons text-3xl text-gray-500" id="favorite<?php echo $result['id']?>">favorite</i></button>
               <?php
             
                }
                ?>
                
               </div> 
                <div>
                <button type="submit" id="<?php echo $result['id']?>" onclick="toggleMore_vert(this)"><i class="material-icons  text-3xl text-white/20 hover:text-cyan-400">more_vert</i></button>
                </div>
                
            </div>
            <div id="more_vert<?php echo $result['id']?>" class="hidden bg-stone-900 ">
                    <ul class="flex flex-col ">
                    <a href="view/edit.php?id=<?php echo $result['id']?>"> <li class="text-center my-1 bg-cyan-500 rounded hover:bg-cyan-100 hover:text-cyan-500 uppercase font-semibold text-white">Edit</li></a>
                    <a href="view/delete.php?id=<?php echo $result['id']?>"> <li class="text-center my-1 bg-red-500 rounded hover:bg-red-100 hover:text-red-500 uppercase font-semibold text-white">Delete</li></a>
                    </ul>
                </div>  
        </div>
    </div>
   
    <?php
    }
    ?>
    <!-- pagenate -->
  <div class="p-3">
  <ul class="flex justify-center ">
    <li>
      <a class="px-3 py-2 ml-0 leading-tight text-cyan-500 bg-white border border-gray-300 rounded-l-lg hover:bg-gray-100 hover:text-cyan-700 dark:bg-gray-800 dark:border-gray-700 dark:text-cyan-400 dark:hover:bg-gray-700 dark:hover:text-white 
      <?php echo($page_no <= 1)? 'cursor-not-allowed' : '';?>"<?php  echo($page_no > 1)? 'href=?page_no=' . $prev : '';?>>Previous</a>
    </li>
    <?php for ($counter = 0; $counter <= $pages; $counter++) { ?>
      <!--  -->
      <?php if ($counter >= ($page_no)) {
        if (($counter < ($page_no + $sides)) || ($counter > ($pages - $sides))) {
          ?>    
    <li>
      <a  href="?page_no=<?= $counter ?>" class="px-3 py-2 leading-tight text-cyan-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-cyan-700 dark:bg-gray-800 dark:border-gray-700 dark:text-cyan-400 dark:hover:bg-gray-700 dark:hover:text-white"><?= $counter ?></a>
    </li>
    <?php } elseif ($counter == ($page_no + $sides)) { ?>
      <li>
      <a  class="px-3 py-2 leading-tight text-cyan-500 bg-white border border-gray-300 hover:bg-gray-100 hover:text-cyan-700 dark:bg-gray-800 dark:border-gray-700 dark:text-cyan-400 dark:hover:bg-gray-700 dark:hover:text-white"><?= $counter ?></a>
    </li>
      <?php
      if (($pages - $page_no) == $limiter - 1) {
        echo $counter + 1;
      } else {
        echo ' <span class="text-white tracking-widest font-semibold">>>></span>';
      }
        } ?>
  <?php
      }
    }
  ?>
    <li>
      <a class="px-3 py-2 leading-tight text-cyan-500 bg-white border border-gray-300 rounded-r-lg hover:bg-gray-100 hover:text-cyan-700 dark:bg-gray-800 dark:border-gray-700 dark:text-cyan-400 dark:hover:bg-gray-700 dark:hover:text-white
      <?php echo($page_no >= $pages) ? 'cursor-not-allowed' : '';?>"<?php echo($page_no < $pages)? 'href=?page_no='.$next : '';?>>Next</a>
    </li>
  </ul>
  <div class="m-2 text-cyan-400 text-center mt-5">
    <strong>Page <span class="text-white"><?php echo $page_no;?></span> of <?php echo $t_r_p?></strong>
  </div>
</div>
 <!-- pagenate end -->
</div>







<?php
include_once('partials/footer.php')
?>










      
<?php

include('model/dbcon.php');
include_once('controller/lyricsController.php');
include_once('controller/abstractController.php');
$id= $_GET['id'];
$status = 'Like';

$like = new Like();

if( $like->like($id,$status)){
    echo "liked Success";
    header("Location:/index.php");
    exit();
}else{
    echo "Like Failed";
    header("Location:/index.php");
    exit();
}

?>
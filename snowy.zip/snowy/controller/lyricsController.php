<?php


class Store extends Config{
    public $url;
    public $title;
    public $lyrics;

    public function __construct($url,$title,$lyrics)
    {
        $embed = $this->getYoutubeId($url);
        $this->url ="https://www.youtube.com/embed/$embed";
        $this->title = $title;
        $this->lyrics = $lyrics;
    }
   
    public function getYoutubeId($urlEmbed){
        $queryString = parse_url($urlEmbed, PHP_URL_QUERY);
        parse_str($queryString,$params);
        if(isset($params['v']) && strlen($params['v'])>0){
            return $params['v'];
        }else{
            return '';
        }
    }

    public function store(){
        $con = $this->con();
        $sql = "INSERT INTO `tblyrics`(`url`,`title`,`lyrics`) VALUE (?,?,?)";
        $data = $con->prepare($sql); 
        if($data->execute([$this->url,$this->title,$this->lyrics])){
            return true;
        }else{
            return false;
        }
    }
    
}





class Show extends Config{
    public function show($id){
        $con = $this->con();
        $sql = "SELECT `id` ,`url`, `title`, `lyrics` ,`favorite` FROM `tblyrics` WHERE `id`= $id";
        $data = $con->prepare($sql);
        $data->execute();
        $result = $data->fetch(PDO::FETCH_ASSOC);
        return $result;
    }
}



class Edit extends Config{
    public function edit($id,$url,$title,$lyrics){
        $con = $this->con();
        $sql = "UPDATE `tblyrics` SET `url`=?,`title`=?,`lyrics`=? WHERE `id` = $id";
        $data = $con->prepare($sql);
       if( $data->execute([$url,$title,$lyrics])){
            return true;
       }else{
        return false;
       }
    }
}
class Delete extends Config{
    public function delete($id){
        $con = $this->con();
        $sql = "DELETE FROM `tblyrics` WHERE `id` = $id";
        $data = $con->prepare($sql);
       if( $data->execute()){
            return true;
       }else{
        return false;
       }
    }
}






class Like extends Config{
    public function like($id,$favorite){
        $con = $this->con();
        $sql = "UPDATE `tblyrics` SET `favorite`='$favorite' WHERE `id` = $id";
        $data = $con->prepare($sql);
       
       if( $data->execute()){
            return true;
       }else{
        return false;
       }
    }
}

class Page extends Config{
    //t_r_p = total record per page
    public function page($offset=null,$t_r_p=null){
        $con = $this->con();
        $sql = "SELECT * FROM `tblyrics` LIMIT $offset,$t_r_p";
        $data = $con->prepare($sql);
        $data->execute();
        $result = $data->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    public function prvNxt($t_r_p){
        $con = $this->con();
        $sql = "SELECT COUNT(*)  as total_records FROM `tblyrics`";
        $data = $con->prepare($sql);
        $data->execute();
        $results = $data->fetch(PDO::FETCH_ASSOC);
        $totalRecords = $results["total_records"];
        $t_n_o_p = ceil($totalRecords / $t_r_p);
        return  $t_n_o_p;
    }
}

//show the favorite or like
class Favorite extends Config{
    //t_r_p = total record per favorite
    public function favorite($offset=null,$t_r_p=null){
        $con = $this->con();
        $sql = "SELECT * FROM `tblyrics` WHERE `favorite`='Like' LIMIT $offset,$t_r_p";
        $data = $con->prepare($sql);
        $data->execute();
        $result = $data->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
    public function prvNxt($t_r_p){
        $con = $this->con();
        $sql = "SELECT COUNT(*)  as total_records FROM `tblyrics`";
        $data = $con->prepare($sql);
        $data->execute();
        $results = $data->fetch(PDO::FETCH_ASSOC);
        $totalRecords = $results["total_records"];
        $t_n_o_p = ceil($totalRecords / $t_r_p);
        return  $t_n_o_p;
    }
}
// class Search extends Config{
//     public function search($title){
//         $con = $this->con();
//         $sql = "SELECT * FROM `tblyrics` WHERE `title` LIKE :title; ";
//         $data = $con->prepare($sql);
//         $data->bindValue(':title','%'.$title.'%');
//         $data->execute();
//         $results = $data->fetchAll(PDO::FETCH_ASSOC);
//         return $results;
//     }
// }
class Search extends Config{
    //t_r_p = total record per search
    public function search($offset=null,$t_r_p=null,$title){
        $con = $this->con();
        $sql = "SELECT * FROM `tblyrics` WHERE `title` Like :title LIMIT $offset,$t_r_p";
        $data = $con->prepare($sql);
        $data->bindValue(':title','%'.$title.'%');
        $data->execute();
        $result = $data->fetchAll(PDO::FETCH_ASSOC);
        return $result;
    }
}




?>
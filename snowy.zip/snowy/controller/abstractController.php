<?php
error_reporting(0);
function store(){
    $url = $_POST['url'];
    $title = $_POST['title'];
    $lyrics = $_POST['lyrics'];
    if(!empty($url && $title && $lyrics)){
        $store = new Store($url,$title,$lyrics);
        if( $store->store()){
            echo '<script>alert("Inserted Success")</script>';
        }else{
            echo '<script>alert("Inserted Failed")</script>';
        }
}
}

function update(){
    if(isset($_GET['btnUpdate'])){
        $id = $_GET['id'];
        $url = $_GET['url'];
        $title = $_GET['title'];
        $lyrics = $_GET['lyrics'];
        $edit = new Edit();
        
        if($edit->edit($id,$url,$title,$lyrics)){
           
          
            echo '<script>alert("Update Success")</script>';
        }else{
            echo '<script>alert("Update Failed")</script>';
        }
    }
}


?>
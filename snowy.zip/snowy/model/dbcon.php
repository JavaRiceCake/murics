<?php
class Config{
    private $user = 'root';
    private $password = '';
    public $pdo = null;
    
    public function con(){
        try{
            $this->pdo  = new PDO('mysql:host=localhost;dbname=dblyrics', $this->user,$this->password);
        }catch(PDOException $e){
            die($e->getMessage());
        }

        return $this->pdo;
        // $this->pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_OBJ);
    }
   
   
}
?>
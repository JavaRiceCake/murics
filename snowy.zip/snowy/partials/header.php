<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Murics.com</title>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>

</head>
<body class="pt-20 bg-stone-900 "> 
    <div class="w-full bg-cyan-500 fixed overflow-hidden  inset-x-0 top-0 z-10  ">
       <div class="navCon flex justify-between flex-wrap  shadow-lg shadow-cyan-100/100">
        <div class=" py-4 basis-4 pl-1 font-bold tracking-widest ">
            <a href="/index.php"> <span>Murics</span></a>
        </div>
        <div class=" py-4 basis-4">
          <form action="/search.php" method="get" class="flex justify-between">
            <input type="search" class="rounded px-1 outline-none border-none " name="search" id="search" placeholder="search..">
            <button type="submit" class="rounded p-1 ml-1 bg-gray-100 hover:bg-gray-200 ">search</button>
          </form>
      </div>
        <div class="flex basis-4">
            <button onclick="toggleNavbar()"><i class="material-icons text-3xl pr-1">format_align_center</i></button>
        </div>
       </div>
       <nav id="navbar-menu" class="hidden ">
        <ul class="flex flex-col ">
          <a href="/index.php"> <li class="text-center my-2 py-1  rounded hover:bg-gray-100 hover:text-cyan-600 uppercase font-semibold text-white">Home</li></a>
          <a href="/view/addlyrics.php"><li class="text-center my-2 py-1  rounded hover:bg-gray-100 hover:text-cyan-600 uppercase font-semibold text-white">Add Lyrics</li></a>
          <a href="/favorite.php"> <li class="text-center my-2  py-1 rounded hover:bg-gray-100 hover:text-cyan-600 uppercase font-semibold text-white">Favorite</li></a>
          <a href="/google.php"> <li class="text-center my-2  py-1 rounded hover:bg-gray-100 hover:text-cyan-600 uppercase font-semibold text-white">Google Search</li></a>
          <a href="/view/aboutus.php"> <li class="text-center my-2  py-1 rounded hover:bg-gray-100 hover:text-cyan-600 uppercase font-semibold text-white">About</li></a>
        </ul>
      </nav>  
      </div>

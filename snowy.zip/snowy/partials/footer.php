
    

    <footer class="text-center p-2 mt-5  bg-cyan-500 text-white font-bold">
        <a href="/index.php"><span>MURICS.COM@2023</span></a> 
    </footer>

    <!-- JavaScript to toggle the navbar menu -->
    <script>
    function toggleNavbar() {
    var menu = document.getElementById("navbar-menu");
    if (menu.style.display === "none") {
        menu.style.display = "block";
    } else {
        menu.style.display = "none";
    }
    }
    function toggleMore_vert(btn) {
    var menu = document.getElementById("more_vert"+btn.id);
    if (menu.style.display === "none") {
        menu.style.display = "block";
    } else {
        menu.style.display = "none";
    }
    }
    
    function like(btnLike) {
        window.location.href= '/like.php?id='+btnLike.id;
        console.log('test');
    }

    function dislike(btnDislike) {
        //if ang value ay like
        window.location.href= '/dislike.php?id='+btnDislike.id;
    }
    </script>

</body>
</html>
<?php
include_once('partials/header.php')
?>
<div id="mainContainer" class="flex w-full flex-nowrap flex-col">

</div>




<?php
include_once('partials/footer.php')
?>
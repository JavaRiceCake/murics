<?php
include('../model/dbcon.php');
include_once('../controller/lyricsController.php');
include_once('../controller/abstractController.php');
$id = $_GET['id'];

$delete = new Delete();
if(isset($id) && $id != ""){
    $delete->delete($id);
    header('location:/index.php');
}else{
    $con->closed();
    header('location:/index.php');
}



?>
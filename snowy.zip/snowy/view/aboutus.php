
<?php
include('../partials/header.php');
?>

<div id="mainContainer">
<a href="/index.php" class="w-20 mb-5 text-cyan-400 flex"><i class="material-icons">arrow_back</i><span>Home</span></a>
   <p class="text-cyan-500 uppercase text-lg p-2 italic font-bold leading-relaxed text-justify">
   this website will help you sing along with your idol In Youtube, it has lyrics that even if you don't know the song, you can still sing along with your idol.
   </p>
    
</div>

<?php
include_once('../partials/footer.php')
?>
      
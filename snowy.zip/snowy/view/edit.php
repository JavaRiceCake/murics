<?php
include('../partials/header.php');
include('../model/dbcon.php');
include_once('../controller/lyricsController.php');
include_once('../controller/abstractController.php');
update();

?>
<div id="mainContainer" class="flex w-full flex-nowrap flex-col p-4">
<?php
    $get = $_GET['id'];
    $show = new Show();
    $result = $show->show($get);

    ?>
     <a href="/index.php" class="w-20 mb-5 text-cyan-400 flex"><i class="material-icons">arrow_back</i><span>Home</span></a>
    <form action="" method="get" class="flex flex-col ">
        <input type="hidden" name="id" value="<?php echo $result['id']?>">
        <label for="url" class="font-semibold text-cyan-300 tracking-widest">Url</label>
        <input type="text" class="outline-none p-2 rounded border-solid border-2 border-gray-400 hover:border-cyan-400 mb-4" name="url" id="url" placeholder="width=100% height=220" required value="<?php echo $result['url']?>">
        <label for="title" class="font-semibold text-cyan-300 tracking-widest">Title</label>
        <input type="text" class="outline-none p-2 rounded border-solid border-2 border-gray-400 hover:border-cyan-400 mb-4" name="title" id="title" placeholder="title.." required value="<?php echo $result['title']?>">
        <label for="lyrics" class="font-semibold text-cyan-300 tracking-widest">Lyrics</label>
        <textarea class="outline-none p-2 rounded border-solid border-2 border-gray-400 hover:border-cyan-400 mb-4" name="lyrics" id="lyrics" cols="30" rows="10" placeholder="lyrics..." required><?php echo $result['lyrics']?></textarea>
        <button type="submit" name="btnUpdate" class="rounded  hover:bg-cyan-400 mb-4 bg-cyan-500 uppercase text-white font-semibold tracking-widest" >Update</button>
    </form>
</div>

<?php

include_once('../partials/footer.php')
?>
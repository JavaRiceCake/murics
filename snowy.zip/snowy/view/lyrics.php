
<?php
include('../partials/header.php');
include('../model/dbcon.php');
include_once('../controller/lyricsController.php');
include_once('../controller/abstractController.php');
?>

<div id="mainContainer" class="flex w-full flex-nowrap flex-col  max-h-full ">
    <?php
    $get = $_GET['id'];
    $show = new Show();
    $result = $show->show($get);
    ?>
    <div id="contentContainer" class="w-full p-3">
    <a href="/index.php" class="w-20 mb-5 text-cyan-400 flex"><i class="material-icons">arrow_back</i><span>Home</span></a>
        <div class="">
        <iframe width="100%" height="220" src="<?php echo $result['url']?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
        </div>
        <div class="max-h-96 overflow-y-scroll">
            <p class="font-semibold mb-2 text-white text-lg " ><?php echo $result['title']?></p>
            <div class="flex flex-col border-solid border-b-2 border-gray-200 pb-1">
            <div>
                <span class="font-semibold text-cyan-400 tracking-widest">Lyrics</span>
<pre class="whitespace-pre-wrap text-white">

<?php echo $result['lyrics']?>
</pre>
            </div>
            <input type="hidden" name="favorite" id="hfavorite" value="<?php echo $result['favorite']?>">
                <?php
                if($result['favorite']=='Like'){
                ?>
                 <button onclick="dislike(this)" id="<?php echo $result['id']?>"><i class="material-icons text-3xl text-red-500" id="favorite<?php echo $result['id']?>">favorite</i></button>
                <?php
                }else{
                ?>
                     <button onclick="like(this)" id="<?php echo $result['id']?>"><i class="material-icons text-3xl text-gray-500" id="favorite<?php echo $result['id']?>">favorite</i></button>
               <?php
             
                }
                ?>     
            </div>
        </div>
    </div>
   
    
</div>

<?php
include_once('../partials/footer.php')
?>
      
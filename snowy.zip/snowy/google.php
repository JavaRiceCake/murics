<?php
include_once('partials/header.php');
?>

<div id="mainContainer" class="flex w-full flex-nowrap flex-col">
<iframe src="https://google.com/search?igu=1" class="w-full h-full absolute"></iframe>
</div>

<?php
include_once('partials/footer.php')
?>










      

